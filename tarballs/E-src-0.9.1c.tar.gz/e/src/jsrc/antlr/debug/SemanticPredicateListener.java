package antlr.debug;

public interface SemanticPredicateListener extends ListenerBase {


    void semanticPredicateEvaluated(SemanticPredicateEvent e);
}
