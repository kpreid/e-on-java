package antlr.debug;

public interface NewLineListener extends ListenerBase {


    void hitNewLine(NewLineEvent e);
}
