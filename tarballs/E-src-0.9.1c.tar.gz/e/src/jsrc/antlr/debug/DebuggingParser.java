package antlr.debug;

/**
 * This type was created in VisualAge.
 */
public interface DebuggingParser {


    String getRuleName(int n);

    String getSemPredName(int n);
}
